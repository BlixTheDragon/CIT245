#include <vector>
#include <string>
#include <iostream>
#include <algorithm>
#include "coinClass.cpp"
using namespace std;

/*
ISSUES:
The sorter 

*/


class sorter
{
  public:
  static void bubbleSort(vector<Coin> &list)
  {
    int checks = 0;    
    //number of times a pair is checked
    int totalSwaps = 0;
    //number of times a pair is switched through the whole sort
    int deltaSwaps = 0;
    //number of swaps in a single iteration

    Coin tempcoin = Coin("null",0,0,0);

    //THE SORTING ALGORITHM
    while (true)
    {
      deltaSwaps = 0;
      for (int i = 0; i<list.size()-1; i++)
      {
        //if listed item is less than the next one, increment the checks counter and don't swap
        if (list.at(i).getValue() < list.at(i+1).getValue())
        {
          checks++;
        }
        //if listed item is greater than the next one, increment the checks and swaps counter and swap
        else if (list.at(i).getValue() > list.at(i+1).getValue())
        {
          checks++;
          deltaSwaps++;
          tempcoin = list.at(i+1);
          list.at(i+1) = list.at(i);
          list.at(i) = tempcoin;
        }
      }
      //postprocess that checks the data
      totalSwaps = totalSwaps + deltaSwaps;
      if (deltaSwaps == 0)
      {
        break;
      }
    }

    //POSTPROCESS
    cout << "SORTED RESULTS:\n";
    for (int i = 0; i<list.size(); i++)
    {
      list.at(i).display();
    }
    cout << "\nNumber of checks: " << checks;
    cout << "\nnumber of swaps: " << totalSwaps;

  }
  static void bogoSort(vector<Coin> &list)
  {
    int checks = 0;    
    //number of times a pair is checked
    int shuffles = 0;
    //number of times a pair is switched through the whole sort

    //Shuffle the list
    BOGO:random_shuffle(list.begin(),list.end());
    for (int i = 0; i<list.size()-1; i++)
    {
      //if listed item is less than the next one, increment the checks counter and don't shuffle
      if (list.at(i).getValue() <= list.at(i+1).getValue())
      {
        checks++;
      }
      //if listed item is greater than the next one, increment the checks and shuffles counter and shuffle the list
      else if (list.at(i).getValue() > list.at(i+1).getValue())
      {
        checks++;
        shuffles++;
        goto BOGO;    
      }
    }
    cout << "\nSORTED RESULTS:\n";
    for (int i = 0; i<list.size(); i++)
    {
      list.at(i).display();
    }
    cout << "\nNumber of checks: " << checks;
    cout << "\nnumber of shuffles: " << shuffles;
  }

};
