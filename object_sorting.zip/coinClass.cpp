#include <string>
#include <iostream>
using namespace std;

class Coin {
private:
  string name;    //Name of the coin
  double value;   //Value of the coin in USD
  double diameter;//Diameter of coin in millimeters
  int mintYear;
public:
  //CONSTRUCTOR METHODS
  //String constructor automatically fills values for standard U.S. coins
  //If not, asks for data about the coin.
  Coin(string input)
  :name{input}
  {
    string request;
    //Autofill in data based on input
    if (input == "quarter")
    {
      value = 25;
      diameter = 24.3;
      cout << "Enter the coin's mint year. ";
      cin >> request;
      mintYear = stoi(request);
    }
    else if (input == "dime")
    {
      value = 10;
      diameter = 17.91;
      cout << "Enter the coin's mint year. ";
      cin >> request;
      mintYear = stoi(request);
    }
    else if (input == "nickel")
    {
      value = 5;
      diameter = 21.21;
      cout << "Enter the coin's mint year. ";
      cin >> request;
      mintYear = stoi(request);
    }
    else if (input == "penny")
    {
      value = 1;
      diameter = 19.05;
      cout << "Enter the coin's mint year. ";
      cin >> request;
      mintYear = stoi(request);
    }
    else if (input == "half dollar")
    {
      value = 50;
      diameter = 30.61;
      cout << "Enter the coin's mint year. ";
      cin >> request;
      mintYear = stoi(request);
    }
    else if (input == "dollar coin")
    {
      value = 100;
      diameter = 26.5;
      cout << "Enter the coin's mint year. ";
      cin >> request;
      mintYear = stoi(request);
    }
    else
    {
      //Ask for input
      cout << "Enter the coin's value in USD cents. ";
      cin >> request;
      value = stod(request);
      cout << "\nEnter the coin's diameter in millimeters. ";
      cin >> request;
      diameter = stod(request);
      cout << "\nEnter the coin's mint year. ";
      cin >> request;
      mintYear = stoi(request);
    }
  }
  //Auto-flll constructor that takes all four values as arguments and fills them in
  Coin(string inputName, double inputValue, double inputDiameter, int inputMintYear)
  :name{inputName}, value{inputValue}, diameter{inputDiameter}, mintYear(inputMintYear)
  {/*No further action required*/}

  //No-Arg constructor that asks for all the info about the coin.
  Coin(){
    string request;
    cout << "\nEnter the coin's name. ";
    cin >> request;
    name = request;
    cout << "Enter the coin's value in USD cents. ";
    cin >> request;
    value = stod(request);
    cout << "Enter the coin's diameter in millimeters. ";
    cin >> request;
    diameter = stod(request);
    cout << "Enter the coin's mint year. ";
    cin >> request;
    mintYear = stoi(request);
  }

  //ACCESSOR METHODS
  //Setters and getters to alter private values
  string getName()               {return name;}
  void setName(string input)     {name = input;}
  double getValue()              {return value;}
  void setValue(double input)    {value = input;}
  double getDiameter()           {return diameter;}
  void setDiameter(double input) {diameter = input;}
  int getMintYear()              {return mintYear;}
  void setMintYear(int input)    {mintYear = input;}

  //DISPLAY METHOD
  //Displays all the specs of a coin.
  void display()
  {
    cout << "\nCoin name: " << name << "\n";
    cout << "Coin value: " << value << " cents\n";
    cout << "Coin diameter: " << diameter << " mm\n";
    cout << "Coin mint year: " << mintYear << "\n";
  }
};