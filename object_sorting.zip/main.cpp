/*
Ryan Artifex

Placeholder Text
*/
#include <string>
#include <iostream>
#include <vector>
//#include "coinClass.cpp"
#include "sortingAlgorithm.cpp"
using namespace std;


int main() {
  srand(time(0));
  vector<Coin> coinJar;
  int jar;
  cout << "\nHow many random coins should I generate? ";
  cin >> jar;
  for (int gen = 0; gen<jar; gen++) 
  {
    //Generate a random cent value
    int randomValue = (rand()%100+1);
    int randomDiameter = rand()%15+15;
    int randomYear = rand()%220+1800;

    Coin inputCoin = Coin("testcoin"+to_string(gen), randomValue, randomDiameter, randomYear);
    inputCoin.display();
    coinJar.push_back(inputCoin);
  }
  string request;
  ASK:cout << "\nEnter 1 to bubble sort the list, enter 2 to bogosort the list." << "\nWARNINGS:\n Attempting to bogosort more than ten coins will take a long time.\n Attempting to bubble sort more than 500 coins will cut off the original unsorted list.\n";
  cin >> request;
  if (request == "1")
  {
    sorter::bubbleSort(coinJar);
  }
  else if (request == "2")
  {
    sorter::bogoSort(coinJar);
  }
  else
  {
    cout << "\nInvalid input.\n";
    goto ASK;
  }

}
