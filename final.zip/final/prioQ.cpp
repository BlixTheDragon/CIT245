/*
PrioQ

A weird implementation of 
a priority queue,hand-spun 
by Ryan Artifex as a final
project for CIT-245
*/

#include<vector>
#include<string>
#include<iostream>
using namespace std;

// Node object that stores an item as a string
// and its corresponding priority as an int
class PrioQNode {
  private:
  //Internals for each node
    string item;
    int priority;
  public:
  //Accessor, mutator, and initializer methods
    PrioQNode(string addItem, int addPrio)
    :item(addItem),priority(addPrio)
    {/*No further action required*/}

    //Setters and Getters
    //Accessors and Mutators
    //or whatever they're called
    int getPriority()
    {
        return priority;
    }
    void setPriority(int set)
    {
        priority = set;
    }
    string getItem()
    {
        return item;
    }
    void setItem(string set)
    {
        item = set;
    }

};

//Globals for use later:

//The queue itself
vector<PrioQNode> q;

   

//Vector is sorted from 0 - n with higher-riority nodes closer to 0
//The insertion algorithm subsorts the list fi-fo due to this

//Iterate through q and cout its contents
void printPrioQ()
{
  cout << "Displaying Queue:\n";
  for (int c = 0; c < q.size(); c++)
  {
    cout << "Item " << c+1 << ": " << q.at(c).getItem() <<"\n"; 
    cout << "Priority: " << q.at(c).getPriority() << "\n\n";     
  }

}


//Ask user for info about the new node,
//then add it to the vector algorithmically
void addNode()
//vector<PrioQNode> addNode()
{
  cout << "Adding a new item to the queue. \n";
  //Set up a new node
  string temp1;
  cout << "What is the item called? (no_spaces)";
  cin >> temp1;
  string temp2;
  cout << "What is the item's priority? ";
  cin >> temp2;
  PrioQNode newNode = PrioQNode(temp1, stoi(temp2));

  //Index sets what node we're comparing
  //By default, it's the last one
  int index = q.size();

  //Prevent out_of_range errors by pushing the node to the end by default
  q.push_back(newNode);

  //Move the index backwards through the list
  retry:index = index-1;

  //First time call to prevent integer underflow
  //this causes an out_of_range error
  if (index == -1)
  {
    //You checked, and the new node was already there.
    goto afterNodeAdded;
  }
  //For every case where the index is not pointing at nothing
  //For reference, indexed node refers to the node at q<index>
  else
  {
    //if the new node has equal or lower priority than the indexed node
    if (newNode.getPriority() <= q.at(index).getPriority())
    {
      //You checked, and the new node was already there.
      goto afterNodeAdded;
    }
    //if the new node has a higher priority than the indexed node
    else if (newNode.getPriority() > q.at(index).getPriority())
    {
      //Move the indexed node to q<index+1>, then put the new node at q<index>
      q.at(index+1) = q.at(index);
      q.at(index) = newNode;
      goto retry;
    }
  }
  afterNodeAdded:
  cout << "Node " << newNode.getItem() << " added with a priority of " << newNode.getPriority() << "\n";
}



//Ask the user if they want to remove the top priority node
//then erase it if requested, or don't if not
void resolveNode()
{
  //In the event that the queue is empty
  if (q.size()==0)
  {
    cout << "What item?\n";
  }
  else
  {
    cout << "The current top-priority item is " << q.at(0).getItem() << ".\n";
    cout << "Resolve this item? (y/n)";
    string input;
    yesno1:
    cin >> input;
    if (input == "y")
    {
      q.erase(q.begin());
      cout << "Item resolved.\n";
    }
    else if (input == "n")
    {
      cout << "Item unresolved. Queue unchanged.\n";
    }
    else
    {
      cout << "Input not understood. Enter y or n. ";
    }
  }
}

//Remove node:
  /*
  Ask the user for an item on the list to remove
  Incrementally search through the vector
  If found:
    q.erase(q.begin()+c)
  If not found:
    Tell the user that the node wasn't found
  Return the updated vector
  */

void removeNode()
{
  printPrioQ();
  cout << "What item would you like to remove? (cAsE sEnSiTiVe, no_spaces) ";
  string input;
  cin >> input;
  bool foundNode = false;

  //Step through the list to find the requested node
  for (int c = 0; c < q.size(); c++)
  {
    if (q.at(c).getItem() == input)
    {
      q.erase(q.begin()+c);
      cout << "Item removed.\n";
      foundNode = true;
    }
  }

  if (foundNode == false)
  {
    cout << "Item not found. Queue unchanged.\n";
  }

}



int main()
{
  //Information
  cout << "\n   PrioQ\n -+-=#=-+-\n";
  cout << "Enter a number for a corresponding task:\n";
  cout << "1. Add an item to the queue\n";
  cout << "2. Remove an item from the queue\n";
  cout << "3. Print out the queue\n";
  cout << "4. Pop off the queue\n";
  cout << "5. Terminate the program\n";

  act:
  cout << "\nWhat would you like to do? ";
  string input;
  int action;
  cin >> input;
  try //Convert string input to a number
  {
    action = stoi(input);
  } 
  catch (invalid_argument) //in the event that a number wasn't entered
  {
    cout << "Input not understood. Enter a number 1-5.";
    goto act;
  }
  switch (action) {
    case 1: //add a node
      addNode();
      goto act;
    case 2: //remove a specified node.
      removeNode();
      goto act;
    case 3: //display the queue
      printPrioQ();
      goto act;
    case 4: //remove node 0
      resolveNode();
      goto act;
    case 5: // teleport to the end of main()
      goto end;
    default: //Entered a number that isn't 1-5
      cout << "Input not understood. Enter a number 1-5.";
      goto act;
  }

//On call to end the program:
end:cout << "Shutting down...\n";
}