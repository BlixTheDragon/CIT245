/* * * * * * * * * * * * * * * * * * * * * *
 * Ryan Artifex                            *
 * Team Optimizer                          *
 *                                         *
 * User inputs info about applicants, and  *
 * program sorts through them for display  *
 * * * * * * * * * * * * * * * * * * * * * */ 




/*
Baked:

Asking user for data
Saving data to object
Saving object to vector
Displaying final results
*/

#include <iostream>
#include <string>
#include <vector>
#include <map>
int recordNumber = 0;
using namespace std; 


//Applicant
//Class used to store data
//Values are initialized with "null" for printing purposes.
class Applicant
{
public:
  string applicantNumber = "null";
  string applicantFirstName = "null";
  string applicantLastName;
  string applicantPosition = "null";
  string applicantExperience = "null";
  string applicantDiscordName = "null";
};
vector<Applicant> applicantList;
Applicant Manager;
Applicant CAD;
Applicant Engineer;
Applicant Other;


//Save Applicant data
//Takes in a string array and writes it to an Applicant object,
//then saves the object to a vector list.
void saveApplicantData(string info[])
{
  Applicant a;
  a.applicantNumber = info[0];
  a.applicantFirstName = info[1];
  a.applicantLastName = info[2];
  //fills in information based on value
  if (info[3] == "1")
  {
    a.applicantPosition = "Management Team";
  }
  else if (info[3] == "2")
  {
    a.applicantPosition = "CAD Team";
  }
  else if (info[3] == "3")
  {
    a.applicantPosition = "Engineering Team";
  }
  else
  {
    a.applicantPosition = info[3];
  }
  a.applicantExperience = info[4];
  //info[5] is just a y/n value that we don't need
  a.applicantDiscordName = info[6];

  applicantList.push_back(a);
  cout << "\nApplicant data saved.\n";
}

//Upload Data
//Sorts info from the user, and displays records with most experience per team
void uploadData()
{
  //Comparison variables
  int recordedExp;
  int reviewedExp;

  //Iterate through the whole list
  for (int i=0;i<applicantList.size();i=i+1)
  {
    Applicant review;
    review = applicantList.at(i);

    //Check what team the reviewed applicant is on
    if (review.applicantPosition == "Management Team")
    {
      //If there is no manager applicant, automatically assign it.
      if (Manager.applicantExperience == "null")
      {
        Manager = review;
      }
      else
      {
        reviewedExp = stoi(review.applicantExperience,nullptr,10);
        recordedExp = stoi(Manager.applicantExperience,nullptr,10);
        //If the current applicant has more years of experience than the currently saved one,
        //overwrite the old one with the new one
        if (reviewedExp > recordedExp)
        {
          Manager = review;
        }
      }
    }
    else if (review.applicantPosition == "CAD Team")
    {
      if (CAD.applicantExperience == "null")
      {
        CAD = review;
      }
      else
      {
        reviewedExp = stoi(review.applicantExperience,nullptr,10);
        recordedExp = stoi(CAD.applicantExperience,nullptr,10);
        if (reviewedExp > recordedExp)
        {
          CAD = review;
        }
      }
    }
    else if (review.applicantPosition == "Engineering Team")
    {
      if (Engineer.applicantExperience == "null")
      {
        Engineer = review;
      }
      else
      {
        reviewedExp = stoi(review.applicantExperience,nullptr,10);
        recordedExp = stoi(Engineer.applicantExperience,nullptr,10);
        if (reviewedExp > recordedExp)
        {
          Engineer = review;
        }
      }
    }
    else
    {
      if (Other.applicantExperience == "null")
      {
        Other = review;
      }
      else
      {
        reviewedExp = stoi(review.applicantExperience,nullptr,10);
        recordedExp = stoi(Other.applicantExperience,nullptr,10);
        if (reviewedExp > recordedExp)
        {
          Other = review;
        }
      }
    }
  }
  //After data is uploaded, display some text
  cout << "\nApplicants uploaded.";
}

//Display results
//Checks the four main Applicant objects and prints their data
void displayResults()
{
  //print applicants with most experience

  cout << "\nChosen Applicants:\n";

  cout << "\nManagement:";
  cout << "\nApplicant " << Manager.applicantNumber;
  cout << "\nName: " << Manager.applicantFirstName << " " << Manager.applicantLastName;
  cout << "\nDiscord account: " << Manager.applicantDiscordName;
  cout << "\nApplicant has " << Manager.applicantExperience << " years of experience\n";

  cout << "\nCAD Team:";
  cout << "\nApplicant " << CAD.applicantNumber;
  cout << "\nName: " << CAD.applicantFirstName << " " << CAD.applicantLastName;
  cout << "\nDiscord account: " << CAD.applicantDiscordName;
  cout << "\nApplicant has " << CAD.applicantExperience << " years of experience\n";

  cout << "\nEngineering Team:";
  cout << "\nApplicant " << Engineer.applicantNumber;
  cout << "\nName: " << Engineer.applicantFirstName << " " << Engineer.applicantLastName;
  cout << "\nDiscord account: " << Engineer.applicantDiscordName;
  cout << "\nApplicant has " << Engineer.applicantExperience << " years of experience\n";

  cout << "\nOther:";
  cout << "\nApplicant " << Other.applicantNumber;
  cout << "\nName: " << Other.applicantFirstName << " " << Other.applicantLastName;
  cout << "\nDiscord account: " << Other.applicantDiscordName;
  cout << "\nApplicant applied for " << Other.applicantPosition;
  cout << "\nApplicant has " << Other.applicantExperience << " years of experience\n";
}




//Request Info
//Method collects six pieces of data and stores it into
//a map as an array of seven strings. At the end, the array
//is saved into an Applicant object
void requestInfo ()
{
  string input[7];
  cout << "Application for Marble Machine X project. \n";
  cout << "        -+-=#=-+-\n";
  //Automatically assigns a record number by a counter to index 0.
  BEGIN:cout << "\nRecord number: \n" << recordNumber;
  input[0] = to_string(recordNumber);
  //Due to a strangeness that I don't quite understand, 
  //saves the name to two separate indexes.
  cout << "\n\nEnter applicant's first and last name. \n";
  cin >> input[1];
  cin >> input[2];
  
  cout << "\nWhat group is the applicant applying for? \nEnter the corresponding number.";
  cout << "\n (1) Project Management Team";
  cout << "\n (2) CAD Team";
  cout << "\n (3) Engineering Team\n";
  cin >> input[3];

  cout << "\nHow many years of experience does the applicant\nhave in this area? Enter a number.\n";
  cin >> input[4];

  RETRY:cout << "\nDoes the applicant have a Discord account? (y/n)\n";
  cin >> input[5];

  //If the user has a discord account, ask for it. If not, write NONE to the value.
  if (input[5] == "y")
  {
    cout << "\nWhat is the applicant's Discord account? \nEnter the name and tag, form AccountName#0000 with no spaces.\n";
    cin >> input[6];
  }
  else if (input[5] == "n")
  {
    input[6] = "NONE";
  }
  else
  {
    cout << "\nInvalid entry. Enter y or n.";
    goto RETRY;
  }

  string check1;
  cout << "\n\nData entered:\n";
  cout << "Applicant Name: " << input[1] << " " << input[2] << "\n";
  cout << "Applicant is applying for Group " << input[3] << "\n";
  cout << "Applicant has " << input[4] << " years of experience.\n";
  if (input[5] == "y")
  {
    cout << "Applicant's discord account is " << input[6];
  }
  else if (input[5] == "n")
  {
      cout << "Applicant does not have a discord account.";
  }
  cout << "\nIs that valid? (y/n)\n";
  cin >> check1;
  if (check1 == "y")
  {
    cout << "\nSaving...";
    saveApplicantData(input);
    
  }
  else if (check1 == "n")
  {
    cout << "\nData not saved.";
  }
  string check2;
  cout << "\nEnter more applicants? (y/n)\n";

  cin >> check1;
  if (check1 == "y")
  {
    recordNumber = recordNumber + 1;
    goto BEGIN;
  }
  else if (check1 == "n")
  {
    string check3;
    cout << "\nDisplay applicant data? (y/n)\n";
    if (check3 == "y")
    {
      uploadData();
      displayResults();
    }
    else if (check3 == "n")
    {
      uploadData();
      cout << "\nResults not displayed.";
    }
  }
}

int main ()
{
  requestInfo();
}//eee